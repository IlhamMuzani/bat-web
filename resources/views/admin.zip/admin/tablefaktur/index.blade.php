@extends('layouts.app')

@section('title', 'Faktur Ekspedisi')

@section('content')
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Faktur Ekspedisi</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item active">Faktur Ekspedisi</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            @if (session('success'))
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h5>
                        <i class="icon fas fa-check"></i> Success!
                    </h5>
                    {{ session('success') }}
                </div>
            @endif
            @if (session('error'))
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h5>
                        <i class="icon fas fa-ban"></i> Error!
                    </h5>
                    {{ session('error') }}
                </div>
            @endif
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Faktur Ekspedisi</h3>
                    <div class="float-right">
                        <a href="{{ url('admin/faktur_ekspedisi') }}" class="btn btn-primary btn-sm">
                            <i class="fas fa-plus"></i> Tambah
                        </a>
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body">

                    <table id="datatables66" class="table table-bordered table-striped" style="font-size: 13px">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th>Faktur Ekspedisi</th>
                                <th>Tanggal</th>
                                <th>Kategori</th>
                                <th>No Kabin</th>
                                <th>Sopir</th>
                                <th>Tujuan</th>
                                <th>Pelanggan</th>
                                <th>Tarif</th>
                                <th>PPH</th>
                                <th>U. Tambahan</th>
                                <th>Total</th>
                                <th class="text-center" width="20">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($inquery as $faktur)
                                <tr>
                                    <td id="editMemoekspedisi" data-toggle="modal"
                                        data-target="#modal-posting-{{ $faktur->id }}" style="cursor: pointer;"
                                        class="text-center">{{ $loop->iteration }}</td>
                                    <td id="editMemoekspedisi" data-toggle="modal"
                                        data-target="#modal-posting-{{ $faktur->id }}" style="cursor: pointer;">
                                        {{ $faktur->kode_faktur }}
                                    </td>
                                    <td id="editMemoekspedisi" data-toggle="modal"
                                        data-target="#modal-posting-{{ $faktur->id }}" style="cursor: pointer;">
                                        {{ $faktur->tanggal_awal }}
                                    </td>
                                    <td id="editMemoekspedisi" data-toggle="modal"
                                        data-target="#modal-posting-{{ $faktur->id }}" style="cursor: pointer;">
                                        {{ $faktur->kategori }}
                                    </td>
                                    <td id="editMemoekspedisi" data-toggle="modal"
                                        data-target="#modal-posting-{{ $faktur->id }}" style="cursor: pointer;">
                                        @if ($faktur->detail_faktur->first())
                                            {{ $faktur->detail_faktur->first()->no_kabin }}
                                        @else
                                            tidak ada
                                        @endif

                                    </td>
                                    <td id="editMemoekspedisi" data-toggle="modal"
                                        data-target="#modal-posting-{{ $faktur->id }}" style="cursor: pointer;">
                                        @if ($faktur->detail_faktur->first())
                                            {{ $faktur->detail_faktur->first()->nama_driver }}
                                        @else
                                            tidak ada
                                        @endif
                                    </td>
                                    <td id="editMemoekspedisi" data-toggle="modal"
                                        data-target="#modal-posting-{{ $faktur->id }}" style="cursor: pointer;">
                                        @if ($faktur->detail_faktur->first())
                                            {{ $faktur->detail_faktur->first()->nama_rute }}
                                        @else
                                            tidak ada
                                        @endif
                                    </td>
                                    <td id="editMemoekspedisi" data-toggle="modal"
                                        data-target="#modal-posting-{{ $faktur->id }}" style="cursor: pointer;">
                                        {{ $faktur->nama_pelanggan }}
                                    </td>
                                    <td id="editMemoekspedisi" data-toggle="modal"
                                        data-target="#modal-posting-{{ $faktur->id }}" style="cursor: pointer;"
                                        class="text-right">
                                        {{ number_format($faktur->total_tarif, 2, ',', '.') }}</td>
                                    <td class="text-right">
                                        {{ number_format($faktur->pph, 2, ',', '.') }}
                                    </td>

                                    <td id="editMemoekspedisi" data-toggle="modal"
                                        data-target="#modal-posting-{{ $faktur->id }}" style="cursor: pointer;"
                                        class="text-right">
                                        {{ number_format($faktur->biaya_tambahan, 2, ',', '.') }}</td>
                                    <td class="text-right">{{ number_format($faktur->grand_total, 2, ',', '.') }}</td>
                                    <td id="editMemoekspedisi" data-toggle="modal"
                                        data-target="#modal-posting-{{ $faktur->id }}" style="cursor: pointer;"
                                        class="text-center">
                                        @if ($faktur->status == 'posting')
                                            <button type="button" class="btn btn-success btn-sm">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        @endif
                                        @if ($faktur->status == 'selesai')
                                            <img src="{{ asset('storage/uploads/indikator/truck.png') }}" height="40"
                                                width="40" alt="Roda Mobil">
                                        @endif
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            @if ($faktur->status == 'unpost')
                                                <a class="dropdown-item posting-btn"
                                                    data-memo-id="{{ $faktur->id }}">Posting</a>
                                                <a class="dropdown-item"
                                                    href="{{ url('admin/inquery_fakturekspedisi/' . $faktur->id . '/edit') }}">Update</a>
                                                @if (auth()->check() && auth()->user()->fitur['inquery faktur ekspedisi show'])
                                                    <a class="dropdown-item"
                                                        href="{{ url('admin/inquery_fakturekspedisi/' . $faktur->id) }}">Show</a>
                                                @endif
                                                @if (auth()->check() && auth()->user()->fitur['inquery faktur ekspedisi delete'])
                                                    <form style="margin-top:5px" method="GET"
                                                        action="{{ route('hapusfaktur', ['id' => $faktur->id]) }}">
                                                        <button type="submit"
                                                            class="dropdown-item btn btn-outline-danger btn-block mt-2">
                                                            </i> Delete
                                                        </button>
                                                    </form>
                                                @endif
                                            @endif
                                            @if ($faktur->status == 'posting')
                                                <a class="dropdown-item unpost-btn"
                                                    data-memo-id="{{ $faktur->id }}">Unpost</a>
                                                @if (auth()->check() && auth()->user()->fitur['inquery faktur ekspedisi show'])
                                                    <a class="dropdown-item"
                                                        href="{{ url('admin/inquery_fakturekspedisi/' . $faktur->id) }}">Show</a>
                                                @endif
                                            @endif
                                            @if ($faktur->status == 'selesai')
                                                @if (auth()->check() && auth()->user()->fitur['inquery faktur ekspedisi show'])
                                                    <a class="dropdown-item"
                                                        href="{{ url('admin/inquery_fakturekspedisi/' . $faktur->id) }}">Show</a>
                                                @endif
                                            @endif
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div class="modal fade" id="modal-loading" tabindex="-1" role="dialog"
                        aria-labelledby="modal-loading-label" aria-hidden="true" data-backdrop="static">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <div class="modal-body text-center">
                                    <i class="fas fa-spinner fa-spin fa-3x text-primary"></i>
                                    <h4 class="mt-2">Sedang Menyimpan...</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
    </section>

    {{-- unpost memo  --}}
    <script>
        $(document).ready(function() {
            $('.unpost-btn').click(function() {
                var memoId = $(this).data('memo-id');

                // Kirim permintaan AJAX untuk melakukan unpost
                $.ajax({
                    url: "{{ url('admin/inquery_fakturekspedisi/unpostfaktur/') }}/" + memoId,
                    type: 'GET',
                    data: {
                        id: memoId
                    },
                    success: function(response) {
                        // Tampilkan pesan sukses atau lakukan tindakan lain sesuai kebutuhan
                        console.log(response);

                        // Tutup modal setelah berhasil unpost
                        $('#modal-posting-' + memoId).modal('hide');

                        // Reload the page to refresh the table
                        location.reload();
                    },
                    error: function(error) {
                        // Tampilkan pesan error atau lakukan tindakan lain sesuai kebutuhan
                        console.log(error);
                    }
                });
            });
        });
    </script>
    {{-- posting memo --}}
    <script>
        $(document).ready(function() {
            $('.posting-btn').click(function() {
                var memoId = $(this).data('memo-id');

                // Kirim permintaan AJAX untuk melakukan unpost
                $.ajax({
                    url: "{{ url('admin/inquery_fakturekspedisi/postingfaktur/') }}/" + memoId,
                    type: 'GET',
                    data: {
                        id: memoId
                    },
                    success: function(response) {
                        // Tampilkan pesan sukses atau lakukan tindakan lain sesuai kebutuhan
                        console.log(response);

                        // Tutup modal setelah berhasil unpost
                        $('#modal-posting-' + memoId).modal('hide');

                        // Reload the page to refresh the table
                        location.reload();
                    },
                    error: function(error) {
                        // Tampilkan pesan error atau lakukan tindakan lain sesuai kebutuhan
                        console.log(error);
                    }
                });
            });
        });
    </script>
    <!-- /.card -->
    <script>
        var tanggalAwal = document.getElementById('tanggal_awal');
        var tanggalAkhir = document.getElementById('tanggal_akhir');

        if (tanggalAwal.value == "") {
            tanggalAkhir.readOnly = true;
        }

        tanggalAwal.addEventListener('change', function() {
            if (this.value == "") {
                tanggalAkhir.readOnly = true;
            } else {
                tanggalAkhir.readOnly = false;
            }

            tanggalAkhir.value = "";
            var today = new Date().toISOString().split('T')[0];
            tanggalAkhir.value = today;
            tanggalAkhir.setAttribute('min', this.value);
        });

        var form = document.getElementById('form-action');

        function cari() {
            form.action = "{{ url('admin/inquery_fakturekspedisi') }}";
            form.submit();
        }
    </script>

    <script>
        $(function(e) {
            $("#select_all_ids").click(function() {
                $('.checkbox_ids').prop('checked', $(this).prop('checked'))
            })
        });

        function printSelectedData() {
            var selectedIds = document.querySelectorAll(".checkbox_ids:checked");
            if (selectedIds.length === 0) {
                alert("Harap centang setidaknya satu item sebelum mencetak.");
            } else {
                var selectedCheckboxes = document.querySelectorAll('.checkbox_ids:checked');
                var selectedIds = [];
                selectedCheckboxes.forEach(function(checkbox) {
                    selectedIds.push(checkbox.value);
                });
                document.getElementById('selectedIds').value = selectedIds.join(',');
                var selectedIdsString = selectedIds.join(',');
                window.location.href = "{{ url('admin/cetak_fakturekspedisifilter') }}?ids=" + selectedIdsString;
                // var url = "{{ url('admin/ban/cetak_pdffilter') }}?ids=" + selectedIdsString;
            }
        }
    </script>

@endsection
